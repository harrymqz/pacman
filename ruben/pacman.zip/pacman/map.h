// Map class
class Map {
    public:
        void mapEnvirons(int rows, int columns);
    private:
    	// int randomSelection(int arr[]);
    	int randomNumber(int limit_inf, int limit_sup);
};