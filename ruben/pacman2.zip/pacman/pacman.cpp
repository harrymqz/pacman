#include <iostream>
#include <random>
#include <GL/glut.h>
#include "map.h"

#define WIDTH 1000
#define HEIGHT 700

using namespace std;
bool check_initial_conditions(int rows, int columns);
void display();

int rows = 0;
int columns = 0;
char **mapa;

int main(int argc,char *argv[]) {
    rows = 31;
    columns = 101;

    /*while (check_initial_conditions(rows, columns)) {
        cout<<"Type the number of rows do you want: ";
        cin>>rows;

        cout<<"Type the number of columns do you want: ";
        cin>>columns;
    }

    if (rows%2 != 0) {
        rows++;
    }

    if (columns%2 == 0) {
        columns++;
    }

    cout<<rows<<" "<<columns<<endl;*/


    class Map map;

    mapa = map.mapEnvirons(rows, columns);

    // int row,column;
    // // Print the map
    // for (row = 0; row < rows; row++) {
    //     for (column = 0; column < columns; column++) {
    //         cout<<mapa[row][column];
    //     }
    //     cout<<"\n";
    // }


    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowPosition(0, 0);
    glutInitWindowSize(WIDTH, HEIGHT);
    glutCreateWindow("Pacman board");

    glutDisplayFunc(display);
    // glutKeyboardFunc(keyboard);

    glMatrixMode(GL_PROJECTION);
    gluOrtho2D(0, WIDTH-1, HEIGHT-1, 0);

    glutMainLoop();

    return 0;
}


void display()
{
    int i,j;

    glClearColor(0.0,0.0,0.0,0.0);
    glClear(GL_COLOR_BUFFER_BIT);

    for(i=0;i<rows;i++) {
        for(j=0;j<columns;j++) {

            if (mapa[i][j] == '0') {
                glColor3f(0,0,255);
            }
            else if (mapa[i][j] == '.') {
                glColor3f(0,0,0);
            }
            
            glBegin(GL_QUADS);

            glVertex2i((j + 1) * WIDTH / columns, i * HEIGHT / rows);
            glVertex2i((j + 1) * WIDTH / columns, (i + 1) * HEIGHT / rows);
            glVertex2i(j * WIDTH / columns, (i + 1) * HEIGHT / rows);
            glVertex2i(j * WIDTH / columns, i * HEIGHT / rows);

            glEnd();
        }
    }

    glutSwapBuffers();

}





bool check_initial_conditions(int rows, int columns) {
    if ((rows >= 33 && rows <= 300) && (columns >= 18 && columns <= 150)) {
        return false;
    } else {
        return true;
    }
}
