// Map class
class Map {
    public:
        char** mapEnvirons(int rows, int columns);
    private:
    	int randomNumber(int limit_inf, int limit_sup);
    	// void draw_map(char mapa[][]);
};