#include <iostream>
#include <time.h>
#include "map.h"
#include <vector>
#include <GL/glut.h>
using std::vector;

using namespace std;

char** Map::mapEnvirons(int rows, int columns) {

    int row, column;
    char** map = 0;
    map = new char*[rows];

    for (int i = 0; i < rows; i++) {
        map[i] = new char[columns];
    }

    // Draw the environs
    for (row = 0; row < rows; row++) {
        for (column = 0; column < columns; column++) {
            if (row == 0 || row == rows-1) {
                map[row][column] = '0';
            }
            else if (row > 0 && row < rows-1 && (column == 0 || column == columns-1)) {
                map[row][column] = '0';
            }
            else {
                map[row][column] = '.';
            }
        }
    }

    srand (time(NULL));

    // Some vars
    int x = 0;
    int y = 0;
    int x_aux = 0;
    int y_aux = 0;

    // Only odd shapes
    int shape_one = ((rows/2)*2)+1;
    int shape_two = ((columns/4)*2+1);
    int shape[2] = {shape_one, shape_two};
    
    // Adjust complexity and density relative to maze size
    int complexity = (int)(0.75*(5*(shape[0]+shape[1])));
    int density = (int)(0.75*(((shape[0]/2)*(shape[1]/2))));

    vector<vector<int>> neighbours;

    int first_dim = 0;
    int random_pos = 0;

    // Make aisles
    for (int i = 0; i < density; i++) {
        x = this->randomNumber(0, (shape[1]/2))*2;
        y = this->randomNumber(0, (shape[0]/2))*2;

        map[y][x] = '0';

        for (int j = 0; j < complexity; j++) {
            first_dim = 0;
            neighbours.clear();

            if (x > 1) {
                first_dim++;

                neighbours.resize(first_dim);
                neighbours[first_dim-1].resize(2);

                neighbours[first_dim-1][0] = y;
                neighbours[first_dim-1][1] = x-2;
            }
            if (x < shape[1]-2) {
                first_dim++;

                neighbours.resize(first_dim);
                neighbours[first_dim-1].resize(2);

                neighbours[first_dim-1][0] = y;
                neighbours[first_dim-1][1] = x+2;
            }
            if (y > 1) {
                first_dim++;

                neighbours.resize(first_dim);
                neighbours[first_dim-1].resize(2);

                neighbours[first_dim-1][0] = y-2;
                neighbours[first_dim-1][1] = x;
            }
            if (y < shape[0]-2) {
                first_dim++;

                neighbours.resize(first_dim);
                neighbours[first_dim-1].resize(2);

                neighbours[first_dim-1][0] = y+2;
                neighbours[first_dim-1][1] = x;
            }

            if (neighbours.size()) {
                random_pos = this->randomNumber(0, neighbours.size()-1);
                y_aux = neighbours[random_pos][0];
                x_aux = neighbours[random_pos][1];

                if (map[y_aux][x_aux] == '.') {
                    map[y_aux][x_aux] = '0';
                    map[y_aux+(y-y_aux)/2][x_aux+(x-x_aux)/2] = '0';
                    x = x_aux;
                    y = y_aux;
                }
            }
        }
    }

    // Mirrored map
    for (row = 0; row < rows; row++) {
        for (column = 0; column < columns/2; column++) {
            map[row][columns-column-1] = map[row][column];
        }
    }

    // // Print the map
    // for (row = 0; row < rows; row++) {
    //     for (column = 0; column < columns; column++) {
    //         cout<<map[row][column];
    //     }
    //     cout<<"\n";
    // }

    return map;

}

int Map::randomNumber(int limit_inf, int limit_sup) {
    return limit_inf + (rand()%(int)limit_sup);
}

// void Map::draw_map(char mapa[][]) {

// }